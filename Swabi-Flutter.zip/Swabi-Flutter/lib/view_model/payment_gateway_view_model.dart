
import 'package:flutter/material.dart';
import 'package:flutter_cab/data/response/api_response.dart';
import 'package:flutter_cab/model/paymentGetWay_model.dart';
import 'package:flutter_cab/respository/payment_gateway_repository.dart';
import 'package:flutter_cab/utils/utils.dart';
import 'package:go_router/go_router.dart';

/// Rental Booking View Model
class PaymentCreateOrderIdViewModel with ChangeNotifier {
  final _myRepo = PaymentCreateOrderIDRepository();
  ApiResponse<PaymentCreateOderIdModel> paymentOrderID = ApiResponse.loading();
  setDataList(ApiResponse<PaymentCreateOderIdModel> response) {
    paymentOrderID = response;
    notifyListeners();
  }
  Future<void> fetchPaymentCreateOrderIdViewModelApi(BuildContext context,data,String? carType,id,date,lati,longi) async {
    setDataList(ApiResponse.loading());
    _myRepo.paymentCreateOrderIDRepositoryApi(data).then((value) async {
      print(data);
      setDataList(ApiResponse.completed(value));
      context.push('/rentalForm/bookYourCab', extra: {
        "carType": carType,
        "userId": id,
        "bookdate": date,
        "longitude":longi,
        "latitude":lati,
        // "totalAmt":totalAmt
      });
      // Utils.flushBarSuccessMessage("Payment Order Id Success", context);
    }).onError((error, stackTrace) {
      // debugPrint(error.toString());
      // Utils.flushBarErrorMessage(error.toString(), context);
      setDataList(ApiResponse.error(error.toString()));
    });
  }
}

/// Rental Booking View Model
class PaymentVerifyViewModel with ChangeNotifier {
  final _myRepo = PaymentVerifyRepository();
  ApiResponse<PaymentVerifyModel> paymentVerify = ApiResponse.loading();
  setDataList(ApiResponse<PaymentVerifyModel> response) {
    paymentVerify = response;
    notifyListeners();
  }
  Future<void> fetchPaymentVerifyViewModelApi(BuildContext context,data) async {
    setDataList(ApiResponse.loading());
    _myRepo.paymentVerifyRepositoryApi(data).then((value) async {
      print(data);
      setDataList(ApiResponse.completed(value));
      Utils.flushBarSuccessMessage("Payment paymentVerify Success", context);
    }).onError((error, stackTrace) {
      // debugPrint(error.toString());
      Utils.flushBarErrorMessage(error.toString(), context);
      setDataList(ApiResponse.error(error.toString()));
    });
  }
}