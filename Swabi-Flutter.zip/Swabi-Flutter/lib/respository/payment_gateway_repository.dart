import 'package:flutter_cab/data/network/base_apiservices.dart';
import 'package:flutter_cab/data/network/network_apiservice.dart';
import 'package:flutter_cab/model/paymentGetWay_model.dart';

///Payment Create OrderID Repo
class PaymentCreateOrderIDRepository {
  final BaseApiServices _apiServices = NetworkApiService();

  Future<dynamic> paymentCreateOrderIDRepositoryApi(data) async {
    try {
      dynamic response = await _apiServices.getPostApiResponse(
          'http://swabi.ap-south-1.elasticbeanstalk.com/'
              'payment/create_order?amount=${data["amount"]}&userId=${data["userId"]}',data);
      print("paymentCreateOrderID Repo api success");
      return response = PaymentCreateOderIdModel.fromJson(response);
    } catch (e) {
      print("paymentCreateOrderID Repo api not successful error");
      print(e);
      rethrow;
    }
  }
}

///Payment Verify Repo
class PaymentVerifyRepository {
  final BaseApiServices _apiServices = NetworkApiService();

  Future<dynamic> paymentVerifyRepositoryApi(data) async {
    try {
      dynamic response = await _apiServices.getPostApiResponse(
          'http://swabi.ap-south-1.elasticbeanstalk.com/'
              'payment/verify_payment',data);
      print("PaymentVerify Repo api success");
      return response = PaymentVerifyModel.fromJson(response);
    } catch (e) {
      print("PaymentVerify Repo api not successful error");
      print(e);
      rethrow;
    }
  }
}