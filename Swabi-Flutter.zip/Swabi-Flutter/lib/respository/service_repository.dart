

import '../data/network/base_apiservices.dart';
import '../data/network/network_apiservice.dart';

class ServiceRepository {

  final BaseApiServices _apiServices = NetworkApiService() ;





}
