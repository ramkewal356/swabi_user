import 'package:flutter/material.dart';
import 'package:flutter_cab/res/Common%20Widgets/common_alertTextfeild.dart';
import 'package:flutter_cab/res/Custom%20%20Button/custom_btn.dart';
import 'package:flutter_cab/res/Custom%20Page%20Layout/commonPage_Layout.dart';
import 'package:flutter_cab/res/customAppBar_widget.dart';
import 'package:flutter_cab/res/login/login_customTextFeild.dart';
import 'package:flutter_cab/res/validationTextFeild.dart';
import 'package:flutter_cab/utils/assets.dart';
import 'package:flutter_cab/utils/color.dart';
import 'package:flutter_cab/utils/text_styles.dart';
import 'package:flutter_cab/utils/utils.dart';
import 'package:flutter_cab/view_model/rental_view_model.dart';
import 'package:provider/provider.dart';

class BookingData {
  final String date;
  final String pickUpTime;
  final String bookerId;
  final String carType;
  final String kilometer;
  final String hour;
  final String price;
  final String pickUpLocation;


  BookingData(
      {required this.date,
      required this.pickUpTime,
      required this.bookerId,
      required this.carType,
      required this.kilometer,
      required this.hour,
      required this.price,
      required this.pickUpLocation,
     });
}

class GuestRentalBookingForm extends StatefulWidget {
  // final BookingData data;
  final String date;
  final String pickUpTime;
  final String bookerId;
  final String carType;
  final String kilometer;
  final String hour;
  final String price;
  final String pickUpLocation;
  final String longi;
  final String lati;

  const GuestRentalBookingForm(
      {super.key,
      // required this.data,
      required this.date,
      required this.pickUpTime,
      required this.bookerId,
      required this.carType,
      required this.kilometer,
      required this.hour,
      required this.price,
      required this.pickUpLocation,
        required this.longi,
        required this.lati});

  @override
  State<GuestRentalBookingForm> createState() => _GuestRentalBookingFormState();
}

class _GuestRentalBookingFormState extends State<GuestRentalBookingForm> {
  List<TextEditingController> controller =
      List.generate(3, (index) => TextEditingController());

  bool loader = false;

  @override
  Widget build(BuildContext context) {
    String status = context.watch<RentalBookingViewModel>().DataList.status.toString();
    // print("${widget.bookerId} Booked Id");
    // print("${widget.pickUpTime} pickUpTime");
    // print("${widget.pickUpLocation} pickUpLocation");
    // print("${widget.date} Date");
    // print("${widget.hour} hour");
    // print("${widget.price} price");
    // print("${widget.carType} carType");
    // print("${widget.kilometer} kilometer");
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: bgGreyColor,
      appBar: const CustomAppBar(
        heading: "Guest Detail",
      ),
      body: PageLayout_Page(
          child: Container(
            child: Column(
              children: [
                // CustomTextFeild(
                //   prefixIcon: true,
                //     img: user,
                //     width: double.infinity,
                //     headingReq: true,
                //     hint: "Enter your name",
                //     heading: "Guest Name",
                //     controller: controller[0]),
                ValidationTextField(
                    headingReq: true,
                    prefixIcon: true,
                    width: double.infinity,
                    validation: true,
                    img: user,
                    hint: "Enter your name",
                    heading: "Guest Name",
                    controller: controller[0]),
                const SizedBox(height: 10),
                CustomTextFeild(
                    width: double.infinity,
                    prefixIcon: true,
                    img: contact,
                    number: true,
                    hint: "XXXXXXXXXX",
                    headingReq: true,
                    heading: "Mobile",
                    controller: controller[1]),
                const SizedBox(height: 10),
                FormCommonSingleAlertSelector(
                  title: "Gender",
                  controller: controller[2],
                  elevation: 0,
                  width: double.infinity,
                  textStyle: titleTextStyle,
                  showIcon: const Icon(
                    Icons.event_seat,
                    color: naturalGreyColor,
                  ),
                  iconReq: false,
                  data: const ["Male", "Female"],
                  // icons: gender,
                  icon: genderImg,
                  border: true,

                  ///Hint Color
                  initialValue: "Select Gender",
                  alertBoxTitle: "Select Gender",
                ),
                // CustomDropDownButton(
                //   controller: controller[2],
                //   hint: "Select Gender",
                //   width:double.infinity,
                //   title: "Gender",
                //   dropDownValues: const ["Male","Female"],
                //   iconReq: false,
                //   iconImg: gender,
                //   iconImgReq: true,
                //   icon: const Icon(Icons.ac_unit_outlined),
                //   selectedValue: "",
                //   // selectedValue: "2 Hr 30 KM",
                //   onTap: () {
                //   },
                //   headingReq: true,
                // ),
                const Spacer(),
                CustomButtonBig(
                  btnHeading: "Book",
                  loading: status == "Status.loading" && loader,
                  onTap: () {

                    if (controller[0].text.isEmpty) {
                      Utils.flushBarErrorMessage("Kindly Enter Name", context);
                    } else if (controller[1].text.isEmpty) {
                      Utils.flushBarErrorMessage(
                          "Kindly Enter Mobile No.", context);
                    } else if (controller[2].text.isEmpty) {
                      Utils.flushBarErrorMessage("Kindly Select Gender", context);
                    } else {
                      loader = true;
                      Provider.of<RentalBookingViewModel>(context, listen: false)
                          .fetchRentalViewModelApi(context, {
                        "date": widget.date,
                        "pickupTime": widget.pickUpTime,
                        "bookerId": widget.bookerId,
                        "carType": widget.carType,
                        "kilometers": widget.kilometer,
                        "hours": widget.hour,
                        "price": widget.price,
                        "pickUpLocation": widget.pickUpLocation,
                        "guestName": controller[0].text,
                        "guestMobile": controller[1].text,
                        "gender": controller[2].text,
                        "locationLatitude" : widget.lati,
                        "locationLongitude": widget.longi
                      },widget.bookerId);
                      // Utils.flushBarSuccessMessage("Your Ride Booked", context);
                    }
                  },
                )
              ],
            ),
          )),
    );
  }
}
