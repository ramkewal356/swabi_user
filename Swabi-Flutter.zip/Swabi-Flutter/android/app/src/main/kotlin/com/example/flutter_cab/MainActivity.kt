package com.example.flutter_cab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
